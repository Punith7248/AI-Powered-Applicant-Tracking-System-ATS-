# AI-Powered Applicant Tracking System (ATS)

A runnable full-stack ATS starter built with React, Material UI, React Query, Express, MongoDB, Multer, resume parsing, optional Gemini AI, optional AWS S3, and optional Nodemailer.

## Requirements
- Node.js 18+
- MongoDB running locally or a MongoDB Atlas connection string
- npm

## Quick start

### 1. Backend
```bash
cd server
cp .env.example .env
npm install
npm run dev
```
Edit `server/.env` and set `MONGO_URI` and `JWT_SECRET`. The default API runs at `http://localhost:5000`.

### 2. Frontend
Open a second terminal:
```bash
cd client
npm install
npm run dev
```
Open the Vite URL, usually `http://localhost:5173`.

### 3. Create accounts
Register one account as **Recruiter** and another as **Applicant**. Recruiters can create jobs; applicants can browse and apply with a PDF or DOCX resume.

## AI and storage configuration
- Without `GEMINI_API_KEY`, the app uses a local skill-overlap scoring fallback, so you can test matching immediately.
- To enable Gemini, set `GEMINI_API_KEY` in `server/.env`.
- Resume files are stored locally in `server/uploads` by default.
- To use S3, set `AWS_REGION`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, and `AWS_S3_BUCKET`. The server switches to S3 when these are all present.
- Email is optional. Configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, and `EMAIL_FROM` to send notifications. Without SMTP, notifications are logged by the server.

## Main API
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/jobs`
- `POST /api/jobs` (recruiter)
- `PUT /api/jobs/:id` (job owner)
- `PATCH /api/jobs/:id/archive` (job owner)
- `POST /api/applications` (applicant, multipart form: `jobId`, `resume`)
- `GET /api/applications/mine` (applicant)
- `GET /api/applications/recruiter` (recruiter)
- `PATCH /api/applications/:id/status` (recruiter)
- `GET /api/applications/:id/download` (authorized recruiter/applicant)

## Notes
This is a development-ready MVP, not a production-certified HR system. Before production, add rate limiting, audit logs, malware scanning, stronger account recovery, retention policies, consent workflows, and a formal bias/validity review of AI scoring. AI scores are decision-support signals, not hiring decisions. Avoid using protected or sensitive characteristics in screening.
